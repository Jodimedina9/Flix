//
//  MovieGridCell.swift
//  Flix
//
//  Created by user189474 on 2/7/21.
//

import UIKit

class MovieGridCell: UICollectionViewCell {
    
    @IBOutlet weak var posterView: UIImageView!
    
}
